face = [2]

denominator = [1.050*10^(-4) 1]

find = tf(face,denominator)
bode(find),grid
